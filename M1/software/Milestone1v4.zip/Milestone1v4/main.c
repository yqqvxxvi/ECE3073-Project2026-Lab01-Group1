#include "nios2_ctrl_reg_macros.h"
#include "sys/alt_stdio.h"
#include "altera_up_avalon_accelerometer_spi.h"

#include <stddef.h>
#include <math.h>

#include "system.h"
#include "hex.h"
#include "accelerometer.h"

#include <stdio.h>
//#include <includes.h>
#include <stdint.h>
#include <string.h>
#include <system.h>
#include <io.h>
//
//volatile int * OutPort_LEDR = (int *) 0x08041140; // 0-7 Led
//volatile int * InPort_COUNTER = (int *) 0x08041120; // MSB
//volatile int * Key1 = (int *) 0x08041110; //
//volatile int * Key0 = (int *) 0x080410D0; //
//volatile int * SW = (int *) 0x080410C0; //
//
//volatile int * Buzzer = (int *) 0x080410B0; //
//volatile int * GreenLight = (int *) 0x080410A0; //
//volatile int * YellowLight = (int *) 0x08041090; //
//volatile int * RedLight = (int *) 0x08041080; //
//
//
//volatile int * GPIO2 = (int *) 0x08041130; //
//volatile int * LED8 = (int *) 0x08041100; //
//volatile int * UART = (int *) 0x08041040; //
//volatile int * HEX012 = (int *) 0x080410F0; //
//volatile int * HEX345 = (int *) 0x08041070; //
//
//volatile int * DRAM = (int *) 0x04000000; //
//volatile int * SPI_RxData = (int *) 0x08041000; //
//volatile int * SPI_TxData = (int *) 0x08041000; //
//volatile int * SPI_Status = (int *) 0x08041000; //
//volatile int * SPI_Control = (int *) 0x08041000; //
//volatile int * SPI_SS = (int *) 0x080410E0; //
//
//#define TRDY 0x40
//#define RRDY 0x80


int main(void);
void interrupt_handler(void);
void the_exception(void);

#define PIO_0_BASE 0x08041140
#define PIO_1_BASE 0x08041100

#define PIO_2_BASE 0x08041120

#define PIO_3_BASE 0x08041110
#define PIO_4_BASE 0x08041130
#define PIO_5_BASE 0x08041070
#define PIO_6_BASE 0x080410F0
#define PIO_7_BASE 0x080410C0


volatile int *OutPort_LEDR      = (int *)PIO_0_BASE;      // 0x08041140
volatile int *OutPort_LED8      = (int *)PIO_1_BASE;      // 0x08041100
volatile int *InPort_COUNTER    = (int *)PIO_2_BASE;      // 0x08041120 MSB
volatile int *InPort_KEY0       = (int *)0x080410D0;      // 0x08041110
volatile int *InPort_KEY1       = (int *)PIO_3_BASE;      // 0x08041110

volatile int *GPIO2_Port        = (int *)PIO_4_BASE;      // 0x08041130
volatile int *OutPort_HEX345    = (int *)PIO_5_BASE;      // 0x08041070
volatile int *OutPort_HEX012    = (int *)PIO_6_BASE;      // 0x080410F0
volatile int *InPort_SW         = (int *)PIO_7_BASE;      // 0x080410C0

#define UART_0_BASE 0x08041040
volatile int *UART              = (int *)UART_0_BASE;         // 0x4009000
volatile int *UART_txdata       = (int *)(UART_0_BASE + 0x4);
volatile int *UART_status       = (int *)(UART_0_BASE + 0x8);
volatile int *UART_control      = (int *)(UART_0_BASE + 0xC);

/* pio_2 is the edge-triggered interrupt input */
volatile int *Counter_IRQMask   = (int *)(PIO_2_BASE + 0x8);
volatile int *Counter_EdgeCap   = (int *)(PIO_2_BASE + 0xC);

volatile int * speaker     = (int *) 0x080410B0;
volatile int * green_LED = (int *) 0x080410A0; //
volatile int * yellow_LED = (int *) 0x08041090; //
volatile int * red_LED = (int *) 0x08041080; //

#define SPI_0_BASE 0x08041000
volatile int * SPI_RxData  = (int *) SPI_0_BASE;
volatile int * SPI_TxData  = (int *) (SPI_0_BASE + 0x4);
volatile int * SPI_Status  = (int *) (SPI_0_BASE + 0x8);
volatile int * SPI_Control = (int *) (SPI_0_BASE + 0xC);

volatile int * SPI_SS      = (int *) 0x080410E0;
#define TRDY 0x40
#define RRDY 0x80

//#define TASK1_STACKSIZE 1024
//#define TASK1_PRIORITY  5

//OS_STK task1_stk[TASK1_STACKSIZE];
//typedef unsigned int OS_STK;
//#define TASK1_STACKSIZE 1024
//#define TASK1_PRIORITY  5

volatile char rx_buffer[32];
volatile int rx_index = 0;
volatile int rx_ready = 0;


volatile char debug_char = 0;
volatile int debug_ready = 0;
volatile int debug_raw = 0;

int pitch_deg;
int roll_deg;
int beepOn=0;
const char *ori;


unsigned char hex_buf[6] = {0};
const char tx_message[] = "HELLO I AM GAY";

void spi_delay(void)
{
    for (volatile int i = 0; i < 1000; i++);
}

void tone_delay(volatile int count)
{
    for (volatile int i = 0; i < count; i++);
}

void beep_cycles(int cycles, int delay_count)
{
    for (int i = 0; i < cycles; i++) {
        *speaker = 0x01;          // ON
        tone_delay(delay_count);
        *speaker = 0x00;          // OFF
        tone_delay(delay_count);
    }
}

uint8_t spi_transfer(uint8_t tx)
{
    uint8_t rx;

    *SPI_SS = 0x0;
    spi_delay();

    while (!(*SPI_Status & TRDY));
    *SPI_TxData = tx;

    while (!(*SPI_Status & RRDY));
    rx = (uint8_t)(*SPI_RxData);

    spi_delay();
    *SPI_SS = 0x1;

    return rx;
}

void uart_delay(void)
{
    volatile int i;
    for (i = 0; i < 500; i++);
}

void uart_send_char(char c)
{
    *UART_txdata = (int)c;
}

void uart_send_string(const char *str)
{
    int i;
    for (i = 0; str[i] != '\0'; i++)
    {
        uart_send_char(str[i]);
        uart_delay();
    }
}

/*Accelerometer INIT*/
alt_up_accelerometer_spi_dev *accel;
alt_32 x_axis;
alt_32 y_axis;
alt_32 z_axis;

//void OSTaskCreateExt(void (*task)(void *p_arg), void *p_arg, void *p_tos,
//                     int prio, int id, void *p_bos, int stk_size,
//                     void *p_ext, int opt) {
//    task(p_arg);
//}

//volatile int sw1 = 0;
//volatile int sw2 = 0;
//volatile int sw3 = 0;
//volatile int sw4 = 0;

int main(void)
{

	accel = alt_up_accelerometer_spi_open_dev(ACCELEROMETER_SPI_0_NAME);
    if (accel == NULL)
    {
        alt_putstr("ACCEL OPEN FAIL\n");
        while (1);
    }
    alt_putstr("ACCEL READY\n");

    *Counter_EdgeCap = 0;
    *Counter_IRQMask = 1;
    *UART_control = 0x80;
    NIOS2_WRITE_IENABLE(0x0);
    alt_putstr("IRQ BOOT\n");
    NIOS2_WRITE_STATUS(0x1);

    int prev_counter, prev_key1,prev_key0, LED8_state = 0;
    prev_counter = (*InPort_COUNTER) & 0x01;
    prev_key1 = (*InPort_KEY1) & 0x01;
    prev_key0 = (*InPort_KEY0) & 0x01;
    *OutPort_LED8 = 1;

    for (int i = 0; i < 6; i++) hex_buf[i] = 0xFF;
    hex_refresh();

    char message[64];
	int index = 0;
	uint8_t rx;

//	(void)pdata;

	*SPI_SS = 0x1;
	*red_LED = 0x00;
	*green_LED = 0x00;   // OFF initially (active-high)
	*speaker   = 0x00;   // OFF initially

    while (1)
    {
    	int sw1 = (*InPort_SW) & 0x1;
    	int sw2 = (*InPort_SW) & 0x2;
    	int sw3 = (*InPort_SW) & 0x4;
    	int sw4 = (*InPort_SW) & 0x8;

    	if ((*UART_status) & 0x80)
		{
			char c = (*UART) & 0xFF;

			if (c == '\r')
			{
				// ignore
			}
			else if (c == '\n' || rx_index >= 31)
			{
				rx_buffer[rx_index] = '\0';
				rx_index = 0;
				rx_ready = 1;
			}
			else
			{
				rx_buffer[rx_index++] = c;
			}
		}

		// ===== PRINT RECEIVED =====
		if (rx_ready)
		{
			rx_ready = 0;
			alt_putstr("ESP SAYS: ");
			alt_putstr(rx_buffer);
			alt_putstr("\n");
			hex_scroll_string((char *)rx_buffer);
		}

		// ===== KEY0 PRESS DETECT =====
		int curr_key0 = (*InPort_KEY0) & 0x1;
//		alt_putstr("key...\n");
		if ((prev_key0 == 1) && (curr_key0 == 0))  // falling edge
		{
			alt_putstr("SENDING...\n");

			uart_send_string("CALL ME DADDY");
			uart_send_char('\n');
		}

		prev_key0 = curr_key0;
		for (volatile int i = 0; i < 1000; i++);
		// ===== KEY1 PRESS DETECT =====
		int curr_key1 = (*InPort_KEY1) & 0x1;
		if ((prev_key1 == 1) && (curr_key1 == 0))  // falling edge
			{
			printf("START SPI STRING RECEIVE\n");

			rx = spi_transfer(0xFF);

			printf("Received byte: 0x%02X", rx);
			if (rx >= 32 && rx <= 126) {
				printf(" ('%c')", rx);
			}
			printf("\n");

			if (rx == '\0') {
				message[index] = '\0';
				printf("Full sentence: %s\n", message);
				printf("-------------------------\n");

				*speaker     = 0x00;   // OFF
				*red_LED = 0x01;   // ON
				*green_LED   = 0x01;   // ON

	//            OSTimeDlyHMSM(0, 0, 1, 0);
				volatile int i;
				for (i = 0; i < 1000; i++);

				*red_LED = 0x00;   // OFF
				*green_LED   = 0x00;   // OFF

				index = 0;
				}
			else {
				*green_LED = 0x00;     // keep OFF until full sentence

				if (index < (int)(sizeof(message) - 1)) {
					message[index++] = (char)rx;

					// Short audible beep burst while bytes are coming in
					beep_cycles(80, 60);
				}
				else {
					message[sizeof(message) - 1] = '\0';
					printf("Buffer overflow, partial sentence: %s\n", message);

					index = 0;
					*speaker   = 0x00; // OFF
					*green_LED = 0x00; // OFF
				}
			}
		}
		prev_key1 = curr_key1;
		for (volatile int i = 0; i < 1000; i++);


        if (sw1 == 1)
        {
        	accelerometer_main();
        	alt_putstr("switch1\n");
        }

        else if (sw2 == 2)
            {
        	}
        else {
            for (int i = 0; i < 6; i++) hex_buf[i] = 0xFF;
            hex_refresh();
            }
    }
}

//
//int main(void)
//{
//    OSInit();
//
//    printf("============================\n");
//
//    OSTaskCreateExt(task1,
//                    NULL,
//                    (void *)&task1_stk[TASK1_STACKSIZE - 1],
//                    TASK1_PRIORITY,
//                    TASK1_PRIORITY,
//                    task1_stk,
//                    TASK1_STACKSIZE,
//                    NULL,
//                    0);
//
//    OSStart();
//    return 0;
//}

